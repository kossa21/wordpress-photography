const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const port = 5000;

app.use(cors());

const shareNowVehicles = JSON.parse(fs.readFileSync('share-now/vehicles.json', 'utf8'));
const freeNowVehicles = JSON.parse(fs.readFileSync('free-now/vehicles.json', 'utf8'));


//-----------------------------------------------------------------
//----------------------------Functions----------------------------
//-----------------------------------------------------------------


//Function to filter the vehicles of Free Now by active or inactive
const filterFreeNowVehicles = (filterBy) => {
    const result = freeNowVehicles.poiList.filter(element => element.state === filterBy);
    return {poiList: result};
}

//Function to filter the array of Share Now by interior
const filterByInterior = (shareNowList, filterBy) => {
    return filterBy === "ALL" ? [...shareNowList] : shareNowList.filter(vehicle => vehicle.interior === filterBy);
}

//Function to filter the array of Share Now by exterior
const filterByExterior = (shareNowList, filterBy) => {
    return filterBy === "ALL" ? [...shareNowList] : shareNowList.filter(vehicle => vehicle.exterior === filterBy);
}

//Function to filter the vehicles of Share Now by the given values for interior and exterior
const filterShareNowVehicles = (interior, exterior) => {
    let filteredVehicles = filterByInterior(shareNowVehicles.placemarks, interior);

    filteredVehicles = filterByExterior(filteredVehicles, exterior);

    return {placemarks: filteredVehicles};
}

//-----------------------------------------------------------------
//----------------------------Endpoints----------------------------
//-----------------------------------------------------------------

// SHARE NOW ROUTE
app.get('/share-now/vehicles', (req, res) => {
    const filterByInterior = req.query.filterByInterior;
    const filterByExterior = req.query.filterByExterior;

    filterByExterior && filterByInterior ?  res.send(JSON.stringify(filterShareNowVehicles(filterByInterior, filterByExterior))) : res.send(JSON.stringify(shareNowVehicles));
});

// FREE NOW ROUTE
app.get('/free-now/vehicles', (req, res) => {
    const filterBy = req.query.filterBy;

    filterBy ? res.send(JSON.stringify(filterFreeNowVehicles(filterBy))) : res.send(JSON.stringify(freeNowVehicles));
});


app.listen(port, () => {
    console.log(`Listening on Port: ${port}`);
});