import React, { useState } from 'react';
import { GoogleMap, LoadScript, Marker, InfoWindow } from '@react-google-maps/api';


const MapContainer = props => {
  
  const locations = props.locations;
  const [ selected, setSelected ] = useState({});

  if(locations.length > 0) {
  
    const defaultCenter = {
        lat: 53.59, 
        lng: 10.07
    }
  
    return (
        <LoadScript
          googleMapsApiKey='AIzaSyBj-oZRmIO6MxQuxPINbbyXIf2yZHDA-wA'
        >
            <GoogleMap
              zoom={10.1}
              center={defaultCenter}
            >
              {
                locations ? 
                  locations.map((location, index) => {
                    return (
                      <Marker 
                        key={index} 
                        position={location.location}
                      />
                    )
                  }) 
                : null
              }
            </GoogleMap>
        </LoadScript>
      )
  } else {
    return (<p>Loading...</p>);
  }
}

export default MapContainer;