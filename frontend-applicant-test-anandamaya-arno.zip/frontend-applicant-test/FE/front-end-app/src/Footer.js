import React from 'react'

const Footer = () => {
    return (
        <div className="footer">
            <p>Developed by Anandamaya Arnó</p>
        </div>
    )
}

export default Footer
