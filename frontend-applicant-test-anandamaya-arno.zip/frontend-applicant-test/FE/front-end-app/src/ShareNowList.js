import React, { useEffect, useState } from 'react';
import Map from './Map';

const ShareNowListFetcher = () => {
    let urlShareNow = "http://localhost:5000/share-now/vehicles";

    const [shareNowList, setShareNowList] = useState([]); 
    const [tableData, setTableData] = useState([]); 
    
    //UseEffect to fetch the list for the first time
    useEffect(() => {
        console.log("Fetching the list of vehicles of Share Now!");
 
        fetch(urlShareNow)
         .then(res => res.json())
         .then(data => {
            setShareNowList(data.placemarks);
            setTableData(data.placemarks);
         })
         .catch(rejected => console.error("On shareNow fetch: ", rejected));
 
         console.log("Sharenow list: ", shareNowList);
     }, []);

     
    //Function to fetch again to get the filtered vehicles
    const filterVehicles = (filterByInterior, filterByExterior) => {
        urlShareNow = `http://localhost:5000/share-now/vehicles?filterByInterior=${filterByInterior}&filterByExterior=${filterByExterior}`;
        
        fetch(urlShareNow)
            .then(res => res.json())
            .then(data => {
                setTableData(data.placemarks);
            })
            .catch(rejected => console.error("On freeNow filtered fetch: ", rejected));
    }

    //Function to call the filter function if the value of the select changes
    const onChange = () => {
        const exteriorValue = document.getElementsByName("exterior")[0].value;
        const interiorValue = document.getElementsByName("interior")[0].value;

        console.log("interior:", interiorValue, "exterior:", exteriorValue);

        filterVehicles(interiorValue, exteriorValue);
    }

    //Create the array of locations for the map
    const locations = tableData.map(vehicle => {
        return {
            id: vehicle.id,
            location: {
                lat: vehicle.coordinates[1],
                lng: vehicle.coordinates[0]
            }
        }
    });


    return (
        <div className="container">
           
           <h1>Share Now vehicle list</h1>

           <div className="flex-container">
               <div className="table-container">
                   <div className="filter-button-container">
                        
                        <label htmlFor="exterior">Exterior</label>
                        <select name="exterior" onChange={onChange} defaultValue="ALL">
                            <option value="GOOD">See Good</option>
                            <option value="UNACCEPTABLE">See Unacceptable</option>
                            <option value="ALL">See All</option>
                        </select>

                        <label htmlFor="interior">Interior</label>
                        <select name="interior" onChange={onChange} defaultValue="ALL">
                            <option value="GOOD">See Good</option>
                            <option value="UNACCEPTABLE">See Unacceptable</option>
                            <option value="ALL">See All</option>
                        </select>

                            
                       <p>{tableData.length} results</p>
                   </div>

                   <ShareNowList data={tableData}/>
               </div>

               <Map locations={locations}/>
           </div>
        </div>
   )
}


const ShareNowList = props => {

    const shareNowList = props.data;

    if (shareNowList.length > 0) {

        return (
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Exterior</th>
                        <th>Interior</th>
                    </tr>
                </thead>

                <tbody>
                    {shareNowList.map(vehicle => {
                        return (
                        <tr key={vehicle.id}>
                            <td>{vehicle.name}</td>
                            <td>{vehicle.address}</td>
                            <td>{vehicle.exterior}</td>
                            <td>{vehicle.interior}</td>
                        </tr>)
                    })}
                </tbody>
            </table>
        )
    } else {
        return <p>Loading...</p>
    }
}

export default ShareNowListFetcher;
