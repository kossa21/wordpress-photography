import React from 'react';
import "./styles/directoring.scss";
import Homepage from './Homepage';
import Header from './Header';
import Footer from './Footer';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import ShareNowList from './ShareNowList';
import FreeNowList from './FreeNowList';

function App() {
  return (
    <div className="App">
      <Header />
      
      <Router>
        <Switch>
          <Route exact path="/">
            <Homepage />
          </Route>

          <Route exact path="/ShareNowList">
            <ShareNowList />
          </Route>

          <Route exact path="/FreeNowList">
            <FreeNowList />
          </Route>

          <Route exact path="/">
            <Homepage />
          </Route>
        </Switch>
      </Router>

      <Footer />
    </div>
  );
}

export default App;
