import React, { useEffect, useState } from 'react';
import Map from './Map';

const FreeNowListFetcher = () => {
    let urlFreeNow = "http://localhost:5000/free-now/vehicles";
    
    const [freeNowList, setFreeNowList] = useState([]); 
    const [tableData, setTableData] = useState([]); 
    
    //UseEffect to fetch the list for the first time
    useEffect(() => {
        console.log("Fetching the list of vehicles of Free Now!");

        fetch(urlFreeNow)
         .then(res => res.json())
         .then(data => {
            setFreeNowList(data.poiList);
            setTableData(data.poiList);
         })
         .catch(rejected => console.error("On freeNow fetch: ", rejected));
    }, []);

    //Function to fetch again to get the filtered vehicles
    const filterVehicles = (filterBy) => {
        if(filterBy) {
            urlFreeNow = `http://localhost:5000/free-now/vehicles?filterBy=${filterBy}`;
        }
        
        fetch(urlFreeNow)
            .then(res => res.json())
            .then(data => {
                setTableData(data.poiList);
            })
            .catch(rejected => console.error("On freeNow filtered fetch: ", rejected));
    }

    //Create the array of locations for the map
    const locations = tableData.map(vehicle => {
        return {
            id: vehicle.id,
            location: {
                lat: vehicle.coordinate.latitude,
                lng: vehicle.coordinate.longitude
            }
        }
    });

     return (
         <div className="container">
            
            <h1>Free Now vehicle list</h1>

            <div className="flex-container">
                <div className="table-container">
                    <div className="filter-button-container">
                        <div className="buttons">
                            <button onClick={() => filterVehicles("ACTIVE")}>Active</button>
                            <button onClick={() => filterVehicles("INACTIVE")}>Inactive</button>
                            <button onClick={() => filterVehicles()}>See All</button>
                        </div>

                        <p>{tableData.length} results</p>
                    </div>

                    <FreeNowList data={tableData}/>
                </div>

                <Map locations={locations}/>
            </div>
         </div>
    )
}


const FreeNowList = props => {
    const freeNowList = props.data;

    if(freeNowList.length > 0) {
        return (
            <table> 
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>State</th>
                        <th>Type</th>
                    </tr>
                </thead>
    
                <tbody>
                    {freeNowList.map(vehicle => {
                        return (
                        <tr key={vehicle.id}>
                            <td>{vehicle.id}</td>
                            <td>{vehicle.state}</td>
                            <td>{vehicle.type}</td>
                        </tr>)
                    })}
                </tbody>
            </table>
        )
    } else {
        return <p>Loading...</p>
    }
}

export default FreeNowListFetcher;
