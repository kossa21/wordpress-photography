import React from 'react'
import {Link} from 'react-router-dom';

const Homepage = () => {
    return (
        <div className="homepage">
            <Link to="/ShareNowList" className="big-button">See Share Now Vehicles</Link>
            <Link to="/FreeNowList" className="big-button">See Free Now Vehicles</Link>
        </div>
    )
}

export default Homepage;
