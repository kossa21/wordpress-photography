import React from 'react';
import logo from './images/FREE_NOW_Logo.png';

const Header = () => {
    return (
        <div className="header">
            <a href="/">
                <img src={logo} alt="free now logo" className="logo"/>
            </a>
        </div>
    )
}

export default Header
